# Lumina – Smart Lighting Automation System (source code)

## Structure
- `index.html`   – page markup (header, house demo, features, how it works, savings calculator, build guide, login / sign up / account / logout views)
- `css/style.css` – all styling, light and dark themes
- `js/script.js`  – house simulation, automation rules, savings calculator, accounts and page routing

## Run locally
Open `index.html` in a browser. No build step or install is needed.

## Deploy on Render (Static Site)
1. Upload this whole folder to a GitHub repository (keep the `css` and `js` folders).
2. On render.com choose New > Static Site and connect the repository.
3. Build Command: leave empty. Publish Directory: `.`

## Notes
- Accounts are stored in the visitor's browser (localStorage) and do not sync between devices. For real authentication use a backend such as Firebase Authentication, Supabase or Node.js.
- Fonts load from Google Fonts; without internet the page falls back to system fonts.
