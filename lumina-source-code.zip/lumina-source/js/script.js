(function(){
'use strict';
var $=function(s,r){return (r||document).querySelector(s)};
var $$=function(s,r){return Array.prototype.slice.call((r||document).querySelectorAll(s))};
var clamp=function(v,a,b){return Math.min(b,Math.max(a,v))};
var lerp=function(a,b,t){return a+(b-a)*t};
var HEX=function(h){return [parseInt(h.slice(1,3),16),parseInt(h.slice(3,5),16),parseInt(h.slice(5,7),16)]};
var toHex=function(a){return '#'+a.map(function(v){return Math.round(clamp(v,0,255)).toString(16).padStart(2,'0')}).join('')};
var mix=function(a,b,t){var A=HEX(a),B=HEX(b);return toHex(A.map(function(v,i){return lerp(v,B[i],t)}))};

/* Theme toggle */
var root=document.documentElement;
$('#themeBtn').addEventListener('click',function(){
  var dark=root.dataset.theme?root.dataset.theme==='dark':window.matchMedia('(prefers-color-scheme: dark)').matches;
  root.dataset.theme=dark?'light':'dark';
});

/* ---------- Model ---------- */
var W=166.667,H=150,HX=110,HY=150;
var ROOMS=[
  {id:'bed',name:'Bedroom',col:0,row:0,watts:12,wf:.9,px:38},
  {id:'study',name:'Study',col:1,row:0,watts:14,wf:1,px:34},
  {id:'bath',name:'Bathroom',col:2,row:0,watts:9,wf:.5,px:34},
  {id:'living',name:'Living room',col:0,row:1,watts:18,wf:1,px:26},
  {id:'kitchen',name:'Kitchen',col:1,row:1,watts:16,wf:.9,px:64},
  {id:'hall',name:'Hallway',col:2,row:1,watts:8,wf:.6,px:60}
];
var BY={};ROOMS.forEach(function(r){BY[r.id]=r});
var BASE_KWH=ROOMS.reduce(function(s,r){return s+r.watts},0)*17/1000;

var SCENES={
  auto:{label:'Automatic'},
  morning:{label:'Morning',rooms:{bed:[40,3000],bath:[70,4000],kitchen:[90,4500],hall:[30,3500]}},
  focus:{label:'Focus',rooms:{study:[100,5500]}},
  movie:{label:'Movie',rooms:{living:[15,2300],hall:[6,2200]}},
  night:{label:'Night',rooms:{hall:[6,2200],bed:[10,2200]}},
  away:{label:'Away',rooms:{}}
};

var state={time:1150,playing:false,mode:'auto',ov:{},last:{},manualRoom:null,selected:'living',
  rules:{occupancy:true,daylight:true,circadian:true,nightpath:true}};

function daylight(h){var x=(h-6)/12;return (x<=0||x>=1)?0:Math.sin(Math.PI*x)}
function interp(pts,h){for(var i=0;i<pts.length-1;i++){if(h<=pts[i+1][0]){var t=(h-pts[i][0])/(pts[i+1][0]-pts[i][0]);return lerp(pts[i][1],pts[i+1][1],t)}}return pts[pts.length-1][1]}
var KPTS=[[0,2200],[6,2200],[8,4500],[11,5600],[15,5600],[18,3800],[20,2700],[22,2300],[24,2200]];
function circadianK(h){return Math.round(interp(KPTS,h)/100)*100}
function scheduledRoom(h){
  if(h<6.5)return 'bed'; if(h<7)return 'bath'; if(h<7.75)return 'kitchen'; if(h<8)return 'hall';
  if(h<12.5)return 'study'; if(h<13.25)return 'kitchen'; if(h<17.5)return 'study'; if(h<18)return 'hall';
  if(h<19)return 'kitchen'; if(h<22)return 'living'; if(h<22.5)return 'bath'; return 'bed';
}
function kToRgb(k){
  k=k/100;var r,g,b;
  if(k<=66){r=255;g=99.4708025861*Math.log(k)-161.1195681661;b=k<=19?0:138.5177312231*Math.log(k-10)-305.0447927307}
  else{r=329.698727446*Math.pow(k-60,-0.1332047592);g=288.1221695283*Math.pow(k-60,-0.0755148492);b=255}
  return [clamp(r,0,255),clamp(g,0,255),clamp(b,0,255)].map(Math.round);
}

/* The automation logic (used live and for the daily estimate) */
function autoState(r,h,occRoom,rules){
  var d=daylight(h);
  var kelvin=rules.circadian?circadianK(h):4000;
  var here=(occRoom===r.id);
  var sleeping=(r.id==='bed'&&here&&(h>=23.25||h<6));
  var occ=rules.occupancy?here:true;
  if(!occ||sleeping){
    if(rules.nightpath&&r.id==='hall'&&d<0.06)return {on:true,level:8,kelvin:2200};
    return {on:false,level:0,kelvin:kelvin};
  }
  var level=100;
  if(rules.daylight)level=100-d*r.wf*95;
  if(rules.circadian){if(h>=21.5||h<6)level=Math.min(level,40);else if(h>=19.5)level=Math.min(level,75)}
  level=Math.round(level);
  if(level<12)return {on:false,level:0,kelvin:kelvin};
  if(r.id==='study'&&rules.circadian)kelvin=Math.min(6500,kelvin+400);
  return {on:true,level:level,kelvin:kelvin};
}
var estCache={};
function dayEstimate(rules){
  var key=JSON.stringify(rules);if(estCache[key]!==undefined)return estCache[key];
  var wh=0;
  for(var m=0;m<1440;m+=5){var h=m/60,occ=scheduledRoom(h);
    ROOMS.forEach(function(r){var a=autoState(r,h,occ,rules);if(a.on)wh+=r.watts*a.level/100*(5/60)})}
  return (estCache[key]=wh/1000);
}
function occupant(h){return state.mode==='away'?null:(state.manualRoom||scheduledRoom(h))}
function effective(r,h,occ){
  var ov=state.ov[r.id];
  if(ov)return {on:ov.on,level:ov.level,kelvin:ov.kelvin,src:'manual'};
  if(state.mode!=='auto'){var c=SCENES[state.mode].rooms[r.id];
    return c?{on:true,level:c[0],kelvin:c[1],src:'scene'}:{on:false,level:0,kelvin:2700,src:'scene'}}
  var a=autoState(r,h,occ,state.rules);a.src='auto';return a;
}

/* ---------- Build the house ---------- */
var NS='http://www.w3.org/2000/svg';
var svg=$('#house'),defs=$('defs',svg),roomsG=$('#rooms',svg);
var WIN='<rect class="win" x="14" y="30" width="40" height="38" rx="2"/><path class="wf" d="M34 30v38M14 49h40"/>';
var FURN={
  bed:'<rect class="f" x="62" y="96" width="90" height="36" rx="5"/><rect class="f" x="62" y="86" width="8" height="46" rx="3"/><rect class="f2" x="76" y="100" width="24" height="14" rx="4"/><rect class="f" x="22" y="116" width="28" height="16" rx="3"/>',
  study:'<rect class="f" x="52" y="104" width="96" height="8" rx="2"/><rect class="f" x="58" y="112" width="6" height="20"/><rect class="f" x="136" y="112" width="6" height="20"/><rect class="f2" x="88" y="80" width="30" height="22" rx="3"/><circle class="f" cx="76" cy="124" r="9"/>',
  bath:'<rect class="f" x="52" y="106" width="98" height="26" rx="12"/><circle class="f2" cx="62" cy="98" r="4"/><rect class="f" x="20" y="112" width="20" height="20" rx="7"/>',
  living:'<rect class="f" x="60" y="94" width="92" height="16" rx="8"/><rect class="f" x="60" y="106" width="92" height="26" rx="9"/><circle class="f" cx="40" cy="124" r="8"/><ellipse class="f2" cx="108" cy="140" rx="36" ry="5"/>',
  kitchen:'<rect class="f" x="14" y="110" width="102" height="22" rx="2"/><circle class="f2" cx="40" cy="121" r="5"/><circle class="f2" cx="60" cy="121" r="5"/><rect class="f" x="128" y="54" width="26" height="78" rx="4"/><path class="wf" d="M141 54v78M134 78v10"/>',
  hall:'<rect class="f" x="100" y="58" width="42" height="74" rx="3"/><circle class="f2" cx="108" cy="98" r="3"/><rect class="f2" x="20" y="112" width="22" height="20" rx="5"/><path class="wf" d="M31 112c-6-14 0-22 0-22"/>'
};
ROOMS.forEach(function(r){
  r.x=HX+r.col*W;r.y=HY+r.row*H;
  defs.insertAdjacentHTML('beforeend',
    '<clipPath id="cp-'+r.id+'"><rect width="'+W+'" height="'+H+'"/></clipPath>'+
    '<radialGradient id="gl-'+r.id+'" cx=".5" cy=".08" r=".8"><stop offset="0" stop-color="#FFC060" stop-opacity=".95"/><stop offset=".45" stop-color="#FFC060" stop-opacity=".35"/><stop offset="1" stop-color="#FFC060" stop-opacity="0"/></radialGradient>');
  var g=document.createElementNS(NS,'g');
  g.setAttribute('class','room');g.setAttribute('transform','translate('+r.x+' '+r.y+')');
  g.setAttribute('role','button');g.setAttribute('tabindex','0');g.dataset.id=r.id;
  g.innerHTML=
   '<g clip-path="url(#cp-'+r.id+')">'+
    '<rect class="rm-base" width="'+W+'" height="'+H+'" fill="#1B2148"/>'+
    FURN[r.id]+
    '<rect class="rm-shade" width="'+W+'" height="'+H+'" fill="#040616" opacity=".6"/>'+
    WIN+
    '<rect class="rm-wash" width="'+W+'" height="'+H+'" fill="#FFC060" opacity="0"/>'+
    '<rect class="rm-glow" width="'+W+'" height="'+H+'" fill="url(#gl-'+r.id+')" opacity="0"/>'+
    '<line x1="83" y1="0" x2="83" y2="8" stroke="#59618F" stroke-width="2"/>'+
    '<circle class="rm-bulb" cx="83" cy="13" r="6" fill="#5B6390"/>'+
    '<rect class="rm-sensor" x="134" y="0" width="14" height="6" rx="2"/>'+
    '<circle class="rm-ping" cx="141" cy="4" r="4"/>'+
    '<text class="rm-name" x="160" y="26" text-anchor="end">'+r.name+'</text>'+
    '<text class="rm-status" x="160" y="40" text-anchor="end">Off</text>'+
   '</g>'+
   '<rect class="rm-sel" x="1.5" y="1.5" width="'+(W-3)+'" height="'+(H-3)+'" rx="3"/>'+
   '<rect width="'+W+'" height="'+H+'" fill="transparent"/>';
  roomsG.appendChild(g);
  r.el={g:g,base:$('.rm-base',g),shade:$('.rm-shade',g),wash:$('.rm-wash',g),glow:$('.rm-glow',g),bulb:$('.rm-bulb',g),
        status:$('.rm-status',g),ping:$('.rm-ping',g),sensor:$('.rm-sensor',g),stops:$$('#gl-'+r.id+' stop',svg)};
  g.addEventListener('click',function(){select(r.id)});
  g.addEventListener('keydown',function(e){if(e.key==='Enter'||e.key===' '){e.preventDefault();select(r.id)}});
});
/* stars */
(function(){var s=1234,rnd=function(){s=(s*16807)%2147483647;return s/2147483647},out='';
  for(var i=0;i<46;i++){out+='<circle cx="'+(rnd()*720).toFixed(1)+'" cy="'+(rnd()*260).toFixed(1)+'" r="'+(0.7+rnd()*1.2).toFixed(1)+'" fill="#fff" opacity="'+(0.4+rnd()*0.6).toFixed(2)+'"/>'}
  $('#stars').innerHTML=out})();

var SKY=[[0,'#070B24','#151C46'],[5,'#070B24','#151C46'],[6.3,'#2F3B7E','#F09A6A'],[7.5,'#4F8FE0','#F6D9B0'],[9,'#4C9BEB','#BFE4FF'],
  [16.5,'#4C9BEB','#BFE4FF'],[18,'#4A4C9A','#FF9A62'],[19.3,'#232A66','#8A4E7C'],[20.5,'#0B1030','#1B2350'],[24,'#070B24','#151C46']];
function skyAt(h){for(var i=0;i<SKY.length-1;i++){if(h<=SKY[i+1][0]){var t=(h-SKY[i][0])/(SKY[i+1][0]-SKY[i][0]);return [mix(SKY[i][1],SKY[i+1][1],t),mix(SKY[i][2],SKY[i+1][2],t)]}}return [SKY[0][1],SKY[0][2]]}
var person=$('#person'),sun=$('#sun'),moon=$('#moon'),stars=$('#stars');
function arc(t){return {x:30+t*660,y:262-Math.pow(Math.sin(Math.PI*clamp(t,0,1)),.6)*225}}

function paintSky(h,d){
  var s=skyAt(h);
  $('#skyTop').setAttribute('stop-color',s[0]);$('#skyBot').setAttribute('stop-color',s[1]);
  svg.style.setProperty('--win',mix(s[0],s[1],.65));
  svg.style.setProperty('--ground',mix('#10221F','#4F8F5E',d));
  svg.style.setProperty('--tree',mix('#0D1B19','#2F6B4A',d));
  var t=(h-6)/12,p=arc(t);
  sun.setAttribute('transform','translate('+p.x.toFixed(1)+' '+p.y.toFixed(1)+')');
  sun.style.opacity=(t>0&&t<1)?clamp(Math.min(t,1-t)*10,0,1):0;
  var tm=((h-18+24)%24)/12,q=arc(tm);
  moon.setAttribute('transform','translate('+q.x.toFixed(1)+' '+q.y.toFixed(1)+')');
  moon.style.opacity=(tm>0&&tm<1)?clamp(Math.min(tm,1-tm)*10,0,1):0;
  stars.style.opacity=clamp(1-d*3,0,1);
}
function paintRoom(r,s,d,occ){
  var L=s.on?s.level/100:0,rgb=kToRgb(s.kelvin),col='rgb('+rgb.join(',')+')',amb=d*r.wf;
  r.el.base.setAttribute('fill',mix('#1B2148','#8593C0',amb*.85));
  r.el.shade.style.opacity=((0.64-0.5*amb)*(1-0.82*L)).toFixed(3);
  r.el.wash.style.fill=col;r.el.wash.style.opacity=(L*.2).toFixed(3);
  r.el.stops.forEach(function(st){st.style.stopColor=col});
  r.el.glow.style.opacity=Math.min(1,L*1.1).toFixed(3);
  r.el.bulb.style.fill=s.on?col:'#5B6390';
  r.el.status.textContent=s.on?(s.level+'% · '+s.kelvin+'K'):'Off';
  var here=(occ===r.id);
  r.el.ping.classList.toggle('on',here);r.el.sensor.classList.toggle('on',here);
  r.el.g.classList.toggle('sel',state.selected===r.id);
  r.el.g.setAttribute('aria-label',r.name+', '+(s.on?s.level+' percent brightness':'light off')+(here?', motion detected':'')+'. Press to select.');
}
function movePerson(occ){
  if(!occ){person.style.opacity=0;return}
  var r=BY[occ];person.style.opacity=1;
  person.style.transform='translate('+(r.x+r.px)+'px,'+(r.y+146)+'px)';
}

/* ---------- Panel ---------- */
var modeChips=$('#modeChips');
Object.keys(SCENES).forEach(function(k){
  var b=document.createElement('button');b.type='button';b.className='chip';b.setAttribute('role','radio');b.dataset.mode=k;b.textContent=SCENES[k].label;
  b.addEventListener('click',function(){state.mode=k;state.ov={};if(k==='away')state.manualRoom=null;render()});
  modeChips.appendChild(b);
});
function fmt(min){var m=Math.floor(min)%1440,hh=Math.floor(m/60),mm=m%60;return ((hh%12)||12)+':'+String(mm).padStart(2,'0')+' '+(hh>=12?'PM':'AM')}
function period(h){return h<5?'Night':h<7?'Dawn':h<12?'Morning':h<17?'Afternoon':h<20?'Evening':'Night'}
function kWord(k){return k<2500?'Candle':k<3200?'Warm white':k<4500?'Neutral':'Daylight'}

function select(id){state.selected=id;render()}
function setOv(r,patch){
  var h=state.time/60,cur=effective(r,h,occupant(h));
  state.ov[r.id]={on:cur.on,level:cur.level,kelvin:cur.kelvin};
  for(var k in patch)state.ov[r.id][k]=patch[k];
  render();
}
$('#rcSwitch').addEventListener('click',function(){
  var r=BY[state.selected],h=state.time/60,cur=effective(r,h,occupant(h));
  if(cur.on)setOv(r,{on:false,level:0});else setOv(r,{on:true,level:state.last[r.id]||70});
});
$('#levelRange').addEventListener('input',function(e){
  var v=+e.target.value;setOv(BY[state.selected],{on:v>0,level:v});
});
$('#kelvinRange').addEventListener('input',function(e){setOv(BY[state.selected],{kelvin:+e.target.value})});
$('#autoBtn').addEventListener('click',function(){delete state.ov[state.selected];render()});
$('#hereBtn').addEventListener('click',function(){
  if(state.mode==='away'){state.mode='auto';state.ov={}}
  state.manualRoom=state.selected;render();
});
$$('[data-rule]').forEach(function(b){b.addEventListener('click',function(){
  var k=b.dataset.rule;state.rules[k]=!state.rules[k];b.setAttribute('aria-checked',String(state.rules[k]));render();
})});

/* time controls */
var timeRange=$('#timeRange');
timeRange.addEventListener('input',function(){stopPlay();state.time=+timeRange.value;state.manualRoom=null;render()});
$('#noonBtn').addEventListener('click',function(){stopPlay();state.time=720;state.manualRoom=null;render()});
$('#nightBtn').addEventListener('click',function(){stopPlay();state.time=0;state.manualRoom=null;render()});
var last=0;
function tick(ts){
  if(!state.playing)return;
  var dt=Math.min(64,ts-last);last=ts;
  state.time=(state.time+dt*0.048)%1440;state.manualRoom=null;render();
  requestAnimationFrame(tick);
}
function startPlay(){state.playing=true;last=performance.now();$('#playBtn').textContent='Pause';requestAnimationFrame(tick)}
function stopPlay(){state.playing=false;$('#playBtn').textContent='Play a day'}
$('#playBtn').addEventListener('click',function(){state.playing?stopPlay():startPlay()});
$('#heroPlay').addEventListener('click',function(){
  document.getElementById('demo').scrollIntoView({behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'start'});
  if(!state.playing)startPlay();
});

function render(){
  var h=state.time/60,d=daylight(h),occ=occupant(h),total=0;
  paintSky(h,d);
  ROOMS.forEach(function(r){
    var s=effective(r,h,occ);r.s=s;paintRoom(r,s,d,occ);
    if(s.on){total+=r.watts*s.level/100;state.last[r.id]=s.level}
  });
  movePerson(occ);

  $('#clockTime').textContent=fmt(state.time);
  $('#clockPeriod').textContent=period(h);
  timeRange.value=Math.round(state.time);

  $('#stPower').textContent=Math.round(total)+' W';
  $('#stDay').textContent=Math.round(d*100)+'%';
  $('#stMotion').textContent=occ?BY[occ].name:'No one home';
  var est=dayEstimate(state.rules),pct=Math.round((1-est/BASE_KWH)*100);
  $('#stEst').textContent=est.toFixed(2)+' kWh';
  $('#stEstSub').textContent='Automatic day: '+(pct>=0?pct+'% less':Math.abs(pct)+'% more')+' than lights left on';

  $$('.chip',modeChips).forEach(function(c){c.setAttribute('aria-checked',String(c.dataset.mode===state.mode))});

  var r=BY[state.selected],s=r.s,ov=!!state.ov[r.id];
  $('#rcName').textContent=r.name;
  var badge=$('#rcBadge');
  badge.textContent=ov?'Manual':(state.mode==='auto'?'Automatic':SCENES[state.mode].label+' scene');
  badge.classList.toggle('manual',ov);
  $('#rcSwitch').setAttribute('aria-checked',String(s.on));
  var lr=$('#levelRange');lr.value=s.on?s.level:0;
  lr.style.setProperty('--track','linear-gradient(90deg,var(--amber) '+lr.value+'%,var(--surface-2) '+lr.value+'%)');
  $('#levelOut').textContent=(s.on?s.level:0)+'%';
  $('#kelvinRange').value=s.kelvin;
  $('#kelvinOut').textContent=kWord(s.kelvin)+' · '+s.kelvin+'K';
  $('#autoBtn').hidden=!ov;
  $('#hereBtn').disabled=(occ===r.id);
  $('#rcNote').textContent=ov?'Automation is paused for this room. Choose Back to automatic to hand it over again.':
    (occ===r.id?'A motion sensor sees you here, so automation keeps this lamp on.':'Change anything here and automation steps aside for this room.');
}

/* ---------- Copy code ---------- */
$('#copyBtn').addEventListener('click',function(){
  var btn=this,text=$('#codeText').textContent;
  function done(){btn.textContent='Copied';setTimeout(function(){btn.textContent='Copy code'},1600)}
  try{navigator.clipboard.writeText(text).then(done,fallback)}catch(e){fallback()}
  function fallback(){var ta=document.createElement('textarea');ta.value=text;ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.select();try{document.execCommand('copy');done()}catch(e){}document.body.removeChild(ta)}
});

/* ---------- Savings calculator ---------- */
var PRICE={'₹':8,'$':0.16,'€':0.25,'£':0.28};
function money(n,cur){return cur+n.toLocaleString(undefined,{maximumFractionDigits:n>=100?0:2,minimumFractionDigits:0})}
function calc(){
  var b=+$('#sv-bulbs').value,hrs=+$('#sv-hours').value,w=Math.max(0,+$('#sv-watts').value||0),p=Math.max(0,+$('#sv-price').value||0),cur=$('#sv-cur').value;
  $('#o-bulbs').textContent=b;$('#o-hours').textContent=hrs+' h';
  var keep=1;if($('#sv-occ').checked)keep*=.75;if($('#sv-day').checked)keep*=.85;if($('#sv-sched').checked)keep*=.9;
  var before=b*w*hrs*30/1000,after=before*keep,saved=before-after;
  $('#r-save').textContent=money(saved*12*p,cur);
  $('#r-cost-before').textContent=money(before*p,cur);$('#r-cost-after').textContent=money(after*p,cur);
  $('#bar-before').style.width='100%';$('#bar-after').style.width=(before>0?after/before*100:0)+'%';
  $('#r-kwh').textContent=saved.toLocaleString(undefined,{maximumFractionDigits:1})+' kWh';
  $('#r-pct').textContent=Math.round((1-keep)*100)+'%';
  $('#r-co2').textContent=Math.round(saved*12*0.7).toLocaleString()+' kg';
}
['sv-bulbs','sv-hours','sv-watts','sv-price','sv-occ','sv-day','sv-sched'].forEach(function(id){$('#'+id).addEventListener('input',calc);$('#'+id).addEventListener('change',calc)});
$('#sv-cur').addEventListener('change',function(){$('#sv-price').value=PRICE[this.value];calc()});

/* ---------- Init ---------- */
/* ---------- Accounts (stored in this browser) ---------- */
var memStore={};
function lsGet(k){try{return localStorage.getItem(k)}catch(e){return memStore['l'+k]||null}}
function lsSet(k,v){try{localStorage.setItem(k,v)}catch(e){memStore['l'+k]=v}}
function lsDel(k){try{localStorage.removeItem(k)}catch(e){delete memStore['l'+k]}}
function ssGet(k){try{return sessionStorage.getItem(k)}catch(e){return memStore['s'+k]||null}}
function ssSet(k,v){try{sessionStorage.setItem(k,v)}catch(e){memStore['s'+k]=v}}
function ssDel(k){try{sessionStorage.removeItem(k)}catch(e){delete memStore['s'+k]}}
var USERS_KEY='lumina.users',SESSION_KEY='lumina.session',EMAIL_RE=/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
var RULE_NAMES={occupancy:'Motion sensing',daylight:'Daylight dimming',circadian:'Colour by time of day',nightpath:'Night path light'};
function has(o,k){return Object.prototype.hasOwnProperty.call(o,k)}
function loadUsers(){try{var u=JSON.parse(lsGet(USERS_KEY)||'{}');return (u&&typeof u==='object')?u:{}}catch(e){return {}}}
function saveUsers(u){lsSet(USERS_KEY,JSON.stringify(u))}
function sessionEmail(){var raw=ssGet(SESSION_KEY)||lsGet(SESSION_KEY);if(!raw)return null;try{return JSON.parse(raw).email||null}catch(e){return null}}
function currentUser(){var e=sessionEmail(),u=loadUsers();return (e&&has(u,e))?u[e]:null}
function startSession(email,remember){var v=JSON.stringify({email:email});ssDel(SESSION_KEY);lsDel(SESSION_KEY);if(remember)lsSet(SESSION_KEY,v);else ssSet(SESSION_KEY,v)}
function endSession(){ssDel(SESSION_KEY);lsDel(SESSION_KEY)}

function bytesToHex(b){return Array.prototype.map.call(new Uint8Array(b),function(x){return x.toString(16).padStart(2,'0')}).join('')}
function newSalt(){var a=new Uint8Array(16);if(window.crypto&&crypto.getRandomValues)crypto.getRandomValues(a);else for(var i=0;i<16;i++)a[i]=Math.floor(Math.random()*256);return bytesToHex(a)}
async function hashPw(pw,saltHex){
  if(window.crypto&&crypto.subtle){
    var salt=Uint8Array.from(saltHex.match(/.{2}/g).map(function(h){return parseInt(h,16)}));
    var key=await crypto.subtle.importKey('raw',new TextEncoder().encode(pw),'PBKDF2',false,['deriveBits']);
    var bits=await crypto.subtle.deriveBits({name:'PBKDF2',salt:salt,iterations:120000,hash:'SHA-256'},key,256);
    return 'p1:'+bytesToHex(bits);
  }
  var s=saltHex+pw,h=5381;for(var i=0;i<s.length;i++)h=((h<<5)+h+s.charCodeAt(i))|0;
  return 'd1:'+(h>>>0).toString(16);
}
async function signUp(name,email,pw){
  var users=loadUsers();
  if(has(users,email))return {error:'That email already has an account. Log in instead.'};
  var salt=newSalt(),hash=await hashPw(pw,salt);
  users[email]={name:name,email:email,salt:salt,hash:hash,created:Date.now(),setup:null};
  saveUsers(users);return {user:users[email]};
}
async function logIn(email,pw){
  var users=loadUsers(),u=has(users,email)?users[email]:null;
  if(!u){await hashPw(pw,newSalt());return {error:'Email or password is incorrect.'}}
  var h=await hashPw(pw,u.salt);
  return h===u.hash?{user:u}:{error:'Email or password is incorrect.'};
}

/* demo <-> account */
function syncRuleSwitches(){$$('[data-rule]').forEach(function(b){b.setAttribute('aria-checked',String(state.rules[b.dataset.rule]))})}
function applySetup(setup){
  if(!setup||!setup.rules)return;
  Object.keys(state.rules).forEach(function(k){if(typeof setup.rules[k]==='boolean')state.rules[k]=setup.rules[k]});
  if(setup.mode&&SCENES[setup.mode]){state.mode=setup.mode;state.ov={}}
  syncRuleSwitches();render();
}
function resetDemo(){
  Object.keys(state.rules).forEach(function(k){state.rules[k]=true});
  state.mode='auto';state.ov={};state.manualRoom=null;syncRuleSwitches();render();
}
$('#saveSetup').addEventListener('click',function(){
  var users=loadUsers(),e=sessionEmail();
  if(!e||!has(users,e)){renderAuthUI();return}
  users[e].setup={rules:Object.assign({},state.rules),mode:state.mode};
  saveUsers(users);$('#saveNote').textContent='Saved to your account.';
});

/* forms */
function fail(box,msg,field){box.textContent=msg;box.hidden=false;if(field){field.setAttribute('aria-invalid','true');field.focus()}return false}
function clearForm(f){$$('.inp',f).forEach(function(i){i.removeAttribute('aria-invalid')});$$('.err',f).forEach(function(e){e.hidden=true;e.textContent=''})}
function setBusy(f,on){var b=$('button[type=submit]',f);if(on){b.dataset.t=b.textContent;b.textContent='Please wait…';b.disabled=true}else{b.textContent=b.dataset.t||b.textContent;b.disabled=false}}
['#loginForm','#signupForm'].forEach(function(s){$(s).addEventListener('input',function(e){e.target.removeAttribute('aria-invalid')})});
$$('[data-reveal]').forEach(function(b){b.addEventListener('click',function(){
  var show=$(b.dataset.reveal.split(',')[0]).type==='password';
  b.dataset.reveal.split(',').forEach(function(sel){$(sel).type=show?'text':'password'});
  b.textContent=show?'Hide':'Show';b.setAttribute('aria-pressed',String(show));
})});

$('#loginForm').addEventListener('submit',async function(e){
  e.preventDefault();var f=this,err=$('#loginErr');clearForm(f);
  var email=$('#li-email').value.trim().toLowerCase(),pw=$('#li-pw').value;
  if(!EMAIL_RE.test(email))return fail(err,'Enter the email you signed up with.',$('#li-email'));
  if(!pw)return fail(err,'Enter your password.',$('#li-pw'));
  setBusy(f,true);var res=await logIn(email,pw);setBusy(f,false);
  if(res.error)return fail(err,res.error,$('#li-pw'));
  startSession(email,$('#li-remember').checked);f.reset();$('#li-remember').checked=true;
  applySetup(res.user.setup);
  location.hash='#/account';
});
$('#signupForm').addEventListener('submit',async function(e){
  e.preventDefault();var f=this,err=$('#signupErr');clearForm(f);
  var name=$('#su-name').value.trim().replace(/\s+/g,' ').slice(0,60),email=$('#su-email').value.trim().toLowerCase(),pw=$('#su-pw').value,pw2=$('#su-pw2').value;
  if(name.length<2)return fail(err,'Enter your name.',$('#su-name'));
  if(!EMAIL_RE.test(email))return fail(err,'Enter a valid email address, like name@example.com.',$('#su-email'));
  if(pw.length<8)return fail(err,'Use at least 8 characters for your password.',$('#su-pw'));
  if(pw!==pw2)return fail(err,'The two passwords do not match.',$('#su-pw2'));
  setBusy(f,true);var res=await signUp(name,email,pw);setBusy(f,false);
  if(res.error)return fail(err,res.error,$('#su-email'));
  startSession(email,true);f.reset();
  location.hash='#/account';
});

/* account page */
function renderAccount(u){
  $('#acHello').textContent='Hi, '+u.name.split(' ')[0];
  $('#acName').textContent=u.name;$('#acEmail').textContent=u.email;
  $('#acSince').textContent=new Date(u.created).toLocaleDateString(undefined,{year:'numeric',month:'long',day:'numeric'});
  var box=$('#acSetup');
  if(!u.setup){box.innerHTML='<p class="note" style="margin-top:12px">Nothing saved yet. Set up the house on the home page and press Save my setup.</p>';return}
  var html='<ul class="setup-list">';
  Object.keys(RULE_NAMES).forEach(function(k){var on=u.setup.rules&&u.setup.rules[k]!==false;
    html+='<li><span>'+RULE_NAMES[k]+'</span><span class="badge'+(on?' manual':'')+'">'+(on?'On':'Off')+'</span></li>'});
  html+='<li><span>House mode</span><span class="badge">'+(SCENES[u.setup.mode]?SCENES[u.setup.mode].label:'Automatic')+'</span></li></ul>';
  box.innerHTML=html;
}
$('#acDelete').addEventListener('click',function(){this.hidden=true;$('#acConfirm').hidden=false;$('#acConfirmYes').focus()});
$('#acCancel').addEventListener('click',function(){$('#acConfirm').hidden=true;$('#acDelete').hidden=false;$('#acDelete').focus()});
var logoutKind=null;
$('#acConfirmYes').addEventListener('click',function(){
  var users=loadUsers(),e=sessionEmail();
  if(e&&has(users,e)){delete users[e];saveUsers(users)}
  endSession();resetDemo();logoutKind='deleted';location.hash='#/logout';
});

/* header + demo save row */
function renderAuthUI(){
  var u=currentUser(),inn=!!u;
  $('#navLogin').hidden=inn;$('#navSignup').hidden=inn;$('#navUser').hidden=!inn;$('#navLogout').hidden=!inn;
  if(inn){$('#navAvatar').textContent=u.name.trim().charAt(0).toUpperCase();$('#navName').textContent=u.name.split(' ')[0]}
  $('#saveSetup').hidden=!inn;
  var note=$('#saveNote');
  if(inn)note.textContent='Saves your automation rules and house mode to your account.';
  else note.innerHTML='<a href="#/login">Log in</a> to save your rules and house mode.';
}

/* router: #/login  #/signup  #/account  #/logout  (anything else shows the home page) */
var homeEl=$('#top'),authEl=$('#authView'),shell=$('#authShell'),baseTitle=document.title,loginNotice=null;
var TITLES={login:'Log in',signup:'Create account',account:'My account',logout:'Logged out'};
function route(initial){
  var m=location.hash.match(/^#\/(login|signup|account|logout)$/),view=m?m[1]:null;
  if(view==='account'&&!currentUser()){loginNotice='Log in to see your account.';location.replace('#/login');return}
  if((view==='login'||view==='signup')&&currentUser()){location.replace('#/account');return}
  if(view==='logout'){
    var had=!!sessionEmail();endSession();if(had)resetDemo();
    var gone=(logoutKind==='deleted');logoutKind=null;
    $('#loTitle').textContent=gone?'Account deleted':'You are logged out';
    $('#loText').textContent=gone?'Your account and saved setup were removed from this browser.':'Your lighting setup stays saved to your account. Log in any time to pick up where you left off.';
  }
  homeEl.hidden=!!view;authEl.hidden=!view;
  document.title=view?TITLES[view]+' – Lumina':baseTitle;
  if(view){
    ['login','signup','account','logout'].forEach(function(v){$('#p-'+v).hidden=(v!==view)});
    shell.classList.toggle('solo',view==='account'||view==='logout');
    if(view==='login'||view==='signup'){clearForm($('#'+view+'Form'))}
    var n=$('#loginNotice');n.hidden=!(view==='login'&&loginNotice);n.textContent=(view==='login'&&loginNotice)||'';loginNotice=null;
    if(view==='account'){var u=currentUser();renderAccount(u);$('#acConfirm').hidden=true;$('#acDelete').hidden=false}
    window.scrollTo({top:0,behavior:'instant'});
    var h1=$('#p-'+view+' h1');h1.setAttribute('tabindex','-1');h1.focus({preventScroll:true});
  }else if(!initial){
    var id=decodeURIComponent(location.hash.slice(1)),t=id?document.getElementById(id):null;
    if(t&&id!=='top')t.scrollIntoView();else window.scrollTo({top:0,behavior:'instant'});
  }
  renderAuthUI();
}
window.addEventListener('hashchange',function(){route(false)});
function initAuth(){var u=currentUser();if(u)applySetup(u.setup);route(true)}

person.style.transition='none';
initAuth();
render();
requestAnimationFrame(function(){requestAnimationFrame(function(){person.style.transition=''})});
calc();
})();
